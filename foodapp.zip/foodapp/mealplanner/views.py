from django.shortcuts import render
from django.http import HttpResponseRedirect,JsonResponse,HttpResponse
from django.views.generic import ListView,DetailView,TemplateView
from django.views.decorators.csrf import csrf_exempt
from mealplanner.models import FoodJournal,AslanFoodJournal,ActivityJournal
from mealplanner.forms import FoodJournalForm,AslanFoodJournalForm,ActivityJournalForm
import json
import timeit
# Create your views here.


class CalendarView(TemplateView):
    template_name='index.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books

class AslanCalendarView(TemplateView):
    template_name='aslan.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books

class JournalView(TemplateView):
    template_name='sample.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books

@csrf_exempt
def journaldata(request):
    journal=ActivityJournal.objects.values()
    mylist=[]
    for item in journal:
        for key, value in item.items():
            # print(key, value)
            if key not in ['id', 'date','completed_ind']:
                mydict = {}
                mydict['title'] = value
                mydict['start'] = item['date']
                mydict['end'] = item['date']
                mydict['editable']=item['completed_ind']
                if mydict['editable']:
                    mydict['backgroundColor']='green'
                else:
                    mydict['backgroundColor']='red'
                mylist.append(mydict)
    return JsonResponse(mylist,safe=False)

@csrf_exempt
def getactivitydata(request):
    activity=ActivityJournal.objects.filter(date=request.POST.get('date')).exists()
    if activity:
        newjson=[]
        for item in list(ActivityJournal.objects.filter(date=request.POST.get('date')).values('id','activity_name','completed_ind')):
            sample={}
            sample['id']=item['id']
            sample['title']=item['activity_name']
            sample['completed']=item['completed_ind']
            newjson.append(sample)
    else:
        newjson=[]
    return JsonResponse(newjson,safe=False)


@csrf_exempt
def updateactivity(request):
    requestData=json.loads(request.POST.get('updateTodos'))
    requestdelData=json.loads(request.POST.get('delTodos'))
    journalData=ActivityJournal.objects.filter(date=request.POST.get('date'))
    if requestdelData:
        for item in requestdelData:
            Todo=ActivityJournal.objects.filter(id=item)
            starttime=timeit.default_timer()
            Todo.delete()
            print("Time taken to delete ", timeit.default_timer()-starttime)
    starttime=timeit.default_timer()
    for item in requestData:
        existingTodo=journalData.filter(id=item['id']).exists()
        if existingTodo and journalData.filter(id=item['id']).values('activity_name')!=item['title']:
            Todo=ActivityJournal.objects.filter(id=item['id'])
            Todo.update(activity_name=item['title'],completed_ind=item['completed'])
        else:
            newTodo=ActivityJournal(activity_name=item['title'],completed_ind=item['completed'],date=request.POST.get('date'))
            starttime=timeit.default_timer()
            newTodo.save()
            print("Time taken to update {}: ".format(item['id']), timeit.default_timer()-starttime)

    context={}
    context['data']="Journal Updated"
    return JsonResponse(context['data'],safe=False)


def getmealorder(meal):
    mealdata={'breakfast':1,'morning_snack':2,'lunch':3,'afternoon_snack':4,'dinner':5}
    return mealdata[meal]

@csrf_exempt
def getmealplan(request):
    meals=FoodJournal.objects.values()
    mylist=[]

    for item in meals:
        for key, value in item.items():
            # print(key, value)
            if key not in ['id', 'date']:
                mydict = {}
                mydict['title'] = value
                mydict['start'] = item['date']
                mydict['end'] = item['date']
                mydict['id']=getmealorder(key)
                mylist.append(mydict)
    return JsonResponse(mylist,safe=False)

@csrf_exempt
def getautodata(request):
    meals=FoodJournal.objects.values()
    mylist=[]

    for item in meals:
        for key, value in item.items():
            if key not in ['id', 'date'] and value not in "":
                mylist.append(value)
    mylist=list(dict.fromkeys(mylist))
    return JsonResponse(mylist,safe=False)


@csrf_exempt
def getdaydata(request):
    meals=FoodJournal.objects.filter(date=request.POST.get('date')).exists()
    if meals:
        data=FoodJournal.objects.filter(date=request.POST.get('date')).values('breakfast','morning_snack','lunch','afternoon_snack','dinner')
        data=list(data)[0]
        newform=FoodJournalForm(data)
    else:
        newform=FoodJournalForm(auto_id=False)
    return HttpResponse(newform.as_p())

@csrf_exempt
def updatejournal(request):
    data=request.POST
    daymeal=FoodJournal.objects.filter(date=request.POST.get('date')).exists()
    if daymeal:
        meal=FoodJournal.objects.filter(date=request.POST.get('date'))
        starttime=timeit.default_timer()
        meal.update(date=data['date'],breakfast=data['breakfast'],
                        morning_snack=data['morning_snack'],
                        lunch=data['lunch'],
                        afternoon_snack=data['afternoon_snack'],
                        dinner=data['dinner']
                        )
        print("Time taken to update", timeit.default_timer()-starttime)
    else:
        newmeal=FoodJournal(
                            date=data['date'],breakfast=data['breakfast'],
                            morning_snack=data['morning_snack'],
                            lunch=data['lunch'],
                            afternoon_snack=data['afternoon_snack'],
                            dinner=data['dinner']
                            )
        newmeal.save()
    print(data)
    return JsonResponse({'response':200},safe=False)




@csrf_exempt
def getaslanmealplan(request):
    meals=AslanFoodJournal.objects.values()
    mylist=[]

    for item in meals:
        for key, value in item.items():
            # print(key, value)
            if key not in ['id', 'date']:
                mydict = {}
                mydict['title'] = value
                mydict['start'] = item['date']
                mydict['end'] = item['date']
                mydict['id']=getmealorder(key)
                mylist.append(mydict)
    return JsonResponse(mylist,safe=False)

@csrf_exempt
def getaslandaydata(request):
    meals=AslanFoodJournal.objects.filter(date=request.POST.get('date')).exists()
    if meals:
        data=AslanFoodJournal.objects.filter(date=request.POST.get('date')).values('breakfast','morning_snack','lunch','afternoon_snack','dinner')
        data=list(data)[0]
        newform=AslanFoodJournalForm(data)
    else:
        newform=AslanFoodJournalForm()
    return HttpResponse(newform.as_p())

@csrf_exempt
def updateaslanjournal(request):
    data=request.POST
    daymeal=AslanFoodJournal.objects.filter(date=request.POST.get('date')).exists()
    if daymeal:
        meal=AslanFoodJournal.objects.filter(date=request.POST.get('date'))
        meal.update(date=data['date'],breakfast=data['breakfast'],
                        morning_snack=data['morning_snack'],
                        lunch=data['lunch'],
                        afternoon_snack=data['afternoon_snack'],
                        dinner=data['dinner']
                        )

    else:
        newmeal=AslanFoodJournal(
                            date=data['date'],breakfast=data['breakfast'],
                            morning_snack=data['morning_snack'],
                            lunch=data['lunch'],
                            afternoon_snack=data['afternoon_snack'],
                            dinner=data['dinner']
                            )
        newmeal.save()


    print(data)
    return JsonResponse({'response':200},safe=False)
