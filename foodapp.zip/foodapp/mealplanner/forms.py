from django import forms
from mealplanner.models import FoodJournal,AslanFoodJournal,ActivityJournal

class FoodJournalForm(forms.ModelForm):
    breakfast=forms.CharField(widget=forms.TextInput(attrs={'id':'breakfast','class':'form-control'}))
    morning_snack=forms.CharField(widget=forms.TextInput(attrs={'id':'morning_snack','class':'form-control'}))
    lunch=forms.CharField(widget=forms.TextInput(attrs={'id':'lunch','class':'form-control'}))
    afternoon_snack=forms.CharField(widget=forms.TextInput(attrs={'id':'afternoon_snack','class':'form-control'}))
    dinner=forms.CharField(widget=forms.TextInput(attrs={'id':'dinner','class':'form-control'}))

    class Meta():
        model=FoodJournal
        fields=('breakfast','morning_snack','lunch','afternoon_snack','dinner')

class AslanFoodJournalForm(forms.ModelForm):
    breakfast=forms.CharField(widget=forms.TextInput(attrs={'id':'breakfast','class':'form-control'}))
    morning_snack=forms.CharField(widget=forms.TextInput(attrs={'id':'morning_snack','class':'form-control'}))
    lunch=forms.CharField(widget=forms.TextInput(attrs={'id':'lunch','class':'form-control'}))
    afternoon_snack=forms.CharField(widget=forms.TextInput(attrs={'id':'afternoon_snack','class':'form-control'}))
    dinner=forms.CharField(widget=forms.TextInput(attrs={'id':'dinner','class':'form-control'}))

    class Meta():
        model=FoodJournal
        fields=('breakfast','morning_snack','lunch','afternoon_snack','dinner')


class ActivityJournalForm(forms.ModelForm):
   activity_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
   completed_ind=forms.BooleanField(widget=forms.CheckboxInput(attrs={'class':'form-control'}))

   class Meta():
       model=ActivityJournal
       fields=('activity_name','completed_ind',)
