window.onload = function () {

   Vue.component('Calendar', {
     delimiters: ['[[', ']]'],
     template:"#template-calendar",
     mounted:
    function (){
     // console.log(this.journaldata);
     let today = new Date().toISOString().slice(0, 10);
     $('#calendar').fullCalendar({  // Open calendar Configuration
       header: {
         left: 'prev,next today',
         center: 'title',
         right: 'month,basicWeek,basicDay'
       },
       themeSystem: 'bootstrap4',
       firstDay:1,
       defaultDate: today,
       navLinks: true, // can click day/week names to navigate views
       dayRender: function (date,cell) {

      },
      eventRender: function (date,cell) {

     },
     dayClick:(date,jsEvent,view)=>{
             this.$emit('childdate',date.format())
         var mod =new Date(date.format())
         $('#modaltitle').text(mod.toDateString());
         $('#mealmodal').modal();
     },
     eventClick: (event,jsEvent) =>{
       this.$emit('childdate',event.start.format())
       var mod =new Date(event.start.format())
       $('#modaltitle').text(mod.toDateString());
       $('#mealmodal').modal();

     },
       editable: true,
       eventOrder:"editable",
       eventLimit: true, // allow "more" link when too many events
       events: {
         url: '../journaldata',
         error: function() {
           $('#script-warning').show();
         },
         success: function (data) {

        }
      },
      eventColor: '#378006',
      eventTextColor: 'white',
    });// Close the calendar Configuration

  }
   });


       Vue.component('Todos', {
         delimiters: ['[[', ']]'],
         template:"#Todos",
         props:['tasks']
       });

       Vue.component('Addtodo', {
         delimiters: ['[[', ']]'],
         template:"#Addtodo",
         props:['title'],
         data(){
           return{
             userinput:""
           }
         },
         watch:{
           title:function(){
             this.userinput=this.title
           }

         }
       });



       Vue.component('Todoitem', {
         delimiters: ['[[', ']]'],
         template:"#Todoitem",
         props:['item'],
         data(){
           return{
             mutuableitem:this.item
           }
         },
         methods:{
           togglecompleted:function(){
             this.mutuableitem.completed=!this.item.completed
           }
           }
       });



       var vm = new Vue({
         delimiters: ['[[', ']]'],
         el: '#app',
         data(){
           return{
             message:"This is vue.js",
             title:"Enter Something",
             todos:[],//{id:1,title:"sample",completed:true}
             deltodos:[],
             date:"",
           }

         },
         methods:{
           updatetitle:function(data){
             this.title=data
           },
           deletetodo:function(data){
             this.todos=this.todos.filter(todo=>todo.id!=data);
             this.deltodos.push(data);
                       },
           additem:function(data){
             newitem={
               id:Math.floor((Math.random() * 10) + 1).toString()+Math.floor((Math.random() * 10) + 1).toString()+Math.floor((Math.random() * 10) + 1).toString()+Math.floor((Math.random() * 10) + 1).toString(),
               title:data,
               completed:false
             }
             this.todos.push(newitem);
             this.title="";
           },
           gettodolist:function(data){
           $.post('../getactivitydata/',{date:data},(res)=>{
             this.todos=res
             this.deltodos=[]
               });
             this.date=data;
             console.log(this.todos);
           },
           updatejournal:function(){
             data=JSON.stringify(this.todos);
             deldata=JSON.stringify(this.deltodos);
            $('#mealmodal .close').click();
             $.post('../updateactivity/',{'updateTodos':data,'date':this.date,'delTodos':deldata},(res)=>{
              //Do something
               console.log(res);
               $('#calendar').fullCalendar( 'refetchEvents' );

               });
           }
         }
       });

}
