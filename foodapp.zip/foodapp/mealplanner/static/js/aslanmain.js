$(document).ready(function() {
  let today = new Date().toISOString().slice(0, 10);

  $('#calendar').fullCalendar({  // Open calendar Configuration
    header: {
      left: 'prev,next today',
      center: 'title',
      right: 'month,basicWeek,basicDay'
    },
    themeSystem: 'bootstrap4',
    firstDay:1,
    defaultDate: today,
    navLinks: true, // can click day/week names to navigate views
    dayRender: function (date,cell) {

   },
   eventRender: function (date,cell) {

  },
   dayClick:function(date,jsEvent,view){
         $.ajax({type:"POST",url: "../getaslandata/",data:{date:date.format()},success: function(data){
                $(".modal-body").html(data);
                var mod =new Date(date.format())
                $('#modaltitle').text(mod.toDateString()+' Meal Plan ');
                $('#modaltitle').attr("data-date",date.format());
                $('#mealmodal').modal();
         }});

   },
   eventClick: function(event,jsEvent) {
     $.post('../getaslandata/',{date:event.start.format()},function(data){
       // Do something
       $(".modal-body").html(data);
       var mod =new Date(event.start.format())
       $('#modaltitle').text(mod.toDateString()+' Meal Plan ');
       $('#modaltitle').attr("data-date",event.start.format());
       $('#mealmodal').modal();
     });

   },
    editable: true,
    eventOrder:"id",
    eventLimit: false, // allow "more" link when too many events
    events: {
      url: '../aslanmeals',
      error: function() {
        $('#script-warning').show();
      },
      success: function () {
    // data will have your json array of event objects

     }
   },
   eventColor:'white',
   eventTextColor:'blue',


 });// Close the calendar Configuration

});

//
// function mycomplete(){
//   var breakfastlist=['Eggs','Chicken','Juice'];
//   $("#breakfast").autocomplete({
//     source:breakfastlist
//   });
// }

function updateaslanjournal(){
  var journaldata={
    date:$('#modaltitle').attr("data-date"),
    breakfast:$("#breakfast").val(),
    morning_snack:$("#morning_snack").val(),
    lunch:$("#lunch").val(),
    afternoon_snack:$("#afternoon_snack").val(),
    dinner:$("#dinner").val()
  }
  console.log(journaldata);
  $.post('../updateaslanjournal/',journaldata,
    function(data){
      console.log("Journal Updated");
    }
);
  $('#mealmodal .close').click();
  $('#calendar').fullCalendar( 'refetchEvents' );
}
