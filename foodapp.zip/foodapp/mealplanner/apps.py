from django.apps import AppConfig


class MealplannerConfig(AppConfig):
    name = 'mealplanner'
