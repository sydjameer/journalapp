from django.contrib import admin
from mealplanner.models import FoodJournal,AslanFoodJournal,ActivityJournal

# Register your models here.
admin.site.register(FoodJournal)
admin.site.register(AslanFoodJournal)
admin.site.register(ActivityJournal)
