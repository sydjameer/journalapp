from django.db import models
from datetime import date


# Create your models here.

class FoodJournal(models.Model):
    date=models.DateField(auto_now=False, auto_now_add=False)
    breakfast=models.CharField(max_length=260,blank=True)
    morning_snack=models.CharField(max_length=260,blank=True)
    lunch=models.CharField(max_length=260,blank=True)
    afternoon_snack=models.CharField(max_length=260,blank=True)
    dinner=models.CharField(max_length=260,blank=True)

    def __str__(self):
        return self.date.__str__()

class AslanFoodJournal(models.Model):
    date=models.DateField(auto_now=False, auto_now_add=False)
    breakfast=models.CharField(max_length=260,blank=True)
    morning_snack=models.CharField(max_length=260,blank=True)
    lunch=models.CharField(max_length=260,blank=True)
    afternoon_snack=models.CharField(max_length=260,blank=True)
    dinner=models.CharField(max_length=260,blank=True)

    def __str__(self):
        return self.date.__str__()

class ActivityJournal(models.Model):
    date=models.DateField(auto_now=False, auto_now_add=False)
    activity_name=models.CharField(max_length=260,blank=True)
    completed_ind=models.BooleanField(default=False)

    def __str__(self):
        return self.activity_name.__str__()+" on "+ self.date.__str__()
